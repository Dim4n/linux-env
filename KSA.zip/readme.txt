         . .:. :.: ::  www.zxtunes.com  :: :.: .:. . 

This file has been downloaded from ZXTUNES (http://zxtunes.com/).
	 
World's biggest ZX Spectrum music collection.
 
To play music downloaded from ZXTUNES, you can use the "ZX Spectrum
Sound Chip Emulator" (http://zxtunes.com/software/ay_emul.zip).


Disclaimer:

To use tunes, downloaded from ZXTUNES, for commercial purposes,
you should get explicit permission from their respective composers.

           Copyright (C) 1998-2007 www.zxtunes.com 